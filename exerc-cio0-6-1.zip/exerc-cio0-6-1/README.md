# Exercício0.6.1

A Pen created on CodePen.io. Original URL: [https://codepen.io/C-ssio-Rodrigues-da-Rosa/pen/QWYKLrv](https://codepen.io/C-ssio-Rodrigues-da-Rosa/pen/QWYKLrv).

